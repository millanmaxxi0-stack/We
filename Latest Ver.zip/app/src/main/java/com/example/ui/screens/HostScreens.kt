package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.HostedServer
import com.example.data.db.RedeemCode
import com.example.data.db.ServerLog
import com.example.data.db.UserProfile
import com.example.ui.viewmodel.HostViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

// Cyber slate themed palettes for standard Material 3 components
val CyberDark = Color(0xFF0F1115)
val CyberCard = Color(0xFF181C24)
val CyberAccent = Color(0xFF38BDF8) // Light blue neon
val CyberPurple = Color(0xFFC084FC) // Neon purple
val CyberWarning = Color(0xFFFBBF24) // Gold warning
val CyberSuccess = Color(0xFF4ADE80) // Neon green
val CyberGray = Color(0xFF94A3B8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContainer(viewModel: HostViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Alert Notification Toast ("سیستم هشداردهی")
    LaunchedEffect(key1 = true) {
        viewModel.alerts.collectLatest { alert ->
            Toast.makeText(context, "⚠️ ALERT: $alert", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = {
            if (currentScreen !is Screen.Auth) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Cloud,
                                contentDescription = "Logo",
                                tint = CyberAccent,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AeroHost",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                letterSpacing = 1.5.sp
                            )
                        }
                    },
                    navigationIcon = {
                        if (currentScreen != Screen.Dashboard) {
                            IconButton(onClick = { viewModel.navigateTo(Screen.Dashboard) }) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Back",
                                    tint = Color.White
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.navigateTo(Screen.TermuxGuide) }) {
                            Icon(
                                imageVector = Icons.Default.Terminal,
                                contentDescription = "Termux Guide",
                                tint = CyberAccent
                            )
                        }
                        IconButton(onClick = { viewModel.navigateTo(Screen.Profile) }) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "Profile Settings",
                                tint = Color.White
                            )
                        }
                        IconButton(onClick = { viewModel.logout() }) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "Log Out",
                                tint = Color.Red
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = CyberDark,
                        titleContentColor = Color.White
                    )
                )
            }
        },
        containerColor = CyberDark
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedVisibility(
                visible = currentScreen == Screen.Auth,
                enter = fadeIn(tween(300)),
                exit = fadeOut(tween(300))
            ) {
                AuthScreen(viewModel)
            }

            AnimatedVisibility(
                visible = currentScreen == Screen.Dashboard,
                enter = fadeIn(tween(300)),
                exit = fadeOut(tween(300))
            ) {
                DashboardScreen(viewModel)
            }

            AnimatedVisibility(
                visible = currentScreen == Screen.CreateServer,
                enter = fadeIn(tween(300)),
                exit = fadeOut(tween(300))
            ) {
                CreateServerScreen(viewModel)
            }

            AnimatedVisibility(
                visible = currentScreen is Screen.Console,
                enter = fadeIn(tween(300)),
                exit = fadeOut(tween(300))
            ) {
                val consoleScreen = currentScreen as? Screen.Console
                if (consoleScreen != null) {
                    ConsoleScreen(viewModel, consoleScreen.serverId)
                }
            }

            AnimatedVisibility(
                visible = currentScreen == Screen.Profile,
                enter = fadeIn(tween(300)),
                exit = fadeOut(tween(300))
            ) {
                ProfileScreen(viewModel)
            }

            AnimatedVisibility(
                visible = currentScreen == Screen.Payment,
                enter = fadeIn(tween(300)),
                exit = fadeOut(tween(300))
            ) {
                PaymentScreen(viewModel)
            }

            AnimatedVisibility(
                visible = currentScreen == Screen.TermuxGuide,
                enter = fadeIn(tween(300)),
                exit = fadeOut(tween(300))
            ) {
                TermuxGuideScreen(viewModel)
            }
        }
    }
}

@Composable
fun AuthScreen(viewModel: HostViewModel) {
    val email by viewModel.loginEmail.collectAsState()
    val password by viewModel.loginPassword.collectAsState()
    val authError by viewModel.authError.collectAsState()

    var isPasswordVisible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Branding Banner
        Icon(
            imageVector = Icons.Default.Dns,
            contentDescription = "Console Server Logo",
            tint = CyberAccent,
            modifier = Modifier
                .size(72.dp)
                .padding(bottom = 8.dp)
        )

        Text(
            text = "AeroHost Console",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            textAlign = TextAlign.Center
        )

        Text(
            text = "Isolate, deploy and manage your web backends instantly.",
            fontSize = 14.sp,
            color = CyberGray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp, bottom = 32.dp)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CyberCard, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Sign In or Register",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { viewModel.loginEmail.value = it },
                    label = { Text("Email Address", color = CyberGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberAccent,
                        unfocusedBorderColor = CyberGray,
                        cursorColor = CyberAccent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("email_input"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = CyberGray) }
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { viewModel.loginPassword.value = it },
                    label = { Text("Password", color = CyberGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberAccent,
                        unfocusedBorderColor = CyberGray,
                        cursorColor = CyberAccent
                    ),
                    visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("password_input"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { viewModel.performLoginOrRegister() }),
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = CyberGray) },
                    trailingIcon = {
                        IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                            Icon(
                                imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = CyberGray
                            )
                        }
                    }
                )

                if (authError != null) {
                    Text(
                        text = authError ?: "",
                        color = Color.Red,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Button(
                    onClick = { viewModel.performLoginOrRegister() },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberAccent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("login_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Sign In / Register",
                        color = CyberDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                // Testing Helper Button
                TextButton(
                    onClick = {
                        viewModel.loginEmail.value = "demo@aerohost.com"
                        viewModel.loginPassword.value = "password123"
                    },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text("Auto Fill Demo Account", color = CyberPurple, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun DashboardScreen(viewModel: HostViewModel) {
    val servers by viewModel.serversList.collectAsState()
    val profile by viewModel.userProfile.collectAsState()
    val allLogs by viewModel.allSystemLogs.collectAsState()

    val runningServers = servers.filter { it.status == "RUNNING" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcoming & Subscription Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        BorderStroke(1.dp, Brush.linearGradient(listOf(CyberAccent, CyberPurple))),
                        RoundedCornerShape(16.dp)
                    )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Hello, ${profile?.name ?: "User"}!",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Active Tier: ${profile?.activeTier ?: "FREE"}",
                            fontSize = 14.sp,
                            color = CyberAccent,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (profile?.twoFactorEnabled == true) "🛡️ 2FA Security Secured" else "⚠️ Enable 2FA in profile settings for security",
                            fontSize = 12.sp,
                            color = if (profile?.twoFactorEnabled == true) CyberSuccess else CyberWarning
                        )
                    }

                    Button(
                        onClick = { viewModel.navigateTo(Screen.Payment) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberPurple),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Upgrade Plan", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Global Statistics Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Total Containers", color = CyberGray, fontSize = 12.sp)
                        Text("${servers.size}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Active (Running)", color = CyberGray, fontSize = 12.sp)
                        Text("${runningServers.size}", color = CyberSuccess, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Backup Status", color = CyberGray, fontSize = 12.sp)
                        Text("Encrypted", color = CyberAccent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Header and Add Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Hosted Server Containers",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )

                Button(
                    onClick = { viewModel.navigateTo(Screen.CreateServer) },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberAccent),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("create_server_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = CyberDark)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Server", color = CyberDark, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (servers.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberCard),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudQueue,
                            contentDescription = null,
                            tint = CyberGray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No active containers hosted yet.",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "Click 'New Server' to spin up your isolated Node.js or Python container.",
                            color = CyberGray,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        } else {
            items(servers) { server ->
                ServerItemCard(
                    server = server,
                    onToggleStatus = { viewModel.toggleServerStatus(server.id) },
                    onOpenConsole = { viewModel.navigateTo(Screen.Console(server.id)) },
                    onDelete = { viewModel.deleteServer(server) }
                )
            }
        }

        // Decentralized Logs Panel ("دیتابیس توزیعشده برای لاگها")
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Distributed Replicated Logs Database",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CyberDark),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "Secure Sync (3 Nodes)",
                                color = CyberSuccess,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Aggregated secure, tamper-proof logs across decentralized node replications.",
                        color = CyberGray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )

                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .background(CyberDark, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        if (allLogs.isEmpty()) {
                            Text(
                                "No active logs generated yet. Boot a server to see system telemetry logs.",
                                color = CyberGray,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        } else {
                            allLogs.take(15).forEach { log ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "[${log.level}] [${log.distributedNode}] ${log.message}",
                                        color = when (log.level) {
                                            "ERROR" -> Color.Red
                                            "WARN" -> CyberWarning
                                            else -> CyberSuccess
                                        },
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ServerItemCard(
    server: HostedServer,
    onToggleStatus: () -> Unit,
    onOpenConsole: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenConsole() }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (server.type == "Node.js") Icons.Default.Javascript else Icons.Default.Code,
                            contentDescription = null,
                            tint = if (server.type == "Node.js") CyberWarning else CyberAccent,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = server.name,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 16.sp
                        )
                    }
                    Text(
                        text = "Domain: ${server.domainName}",
                        color = CyberGray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (server.status == "RUNNING") Color(0x224ADE80) else Color(0x22EF4444)
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(
                            text = server.status,
                            color = if (server.status == "RUNNING") CyberSuccess else Color.Red,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    IconButton(onClick = { onToggleStatus() }) {
                        Icon(
                            imageVector = if (server.status == "RUNNING") Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = "Toggle Server",
                            tint = if (server.status == "RUNNING") Color.Red else CyberSuccess
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = CyberDark, thickness = 1.dp)
            Spacer(modifier = Modifier.height(12.dp))

            // Resource meters
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MiniResourceProgress(
                    title = "RAM",
                    current = server.ramUsageMb,
                    limit = server.ramLimitMb.toDouble(),
                    unit = "MB"
                )
                MiniResourceProgress(
                    title = "CPU Load",
                    current = server.cpuUsageMb,
                    limit = server.cpuLoadLimitMb.toDouble(),
                    unit = "MB"
                )
                MiniResourceProgress(
                    title = "Disk",
                    current = server.diskUsageMb,
                    limit = server.diskLimitMb.toDouble(),
                    unit = "MB"
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Type: ${server.type}  |  Tier: ${server.tier}",
                    color = CyberGray,
                    fontSize = 11.sp
                )

                Text(
                    text = "Configure & Deploy Console →",
                    color = CyberAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun MiniResourceProgress(title: String, current: Double, limit: Double, unit: String) {
    val progress = if (limit > 0) (current / limit).toFloat().coerceIn(0f, 1f) else 0f
    val progressColor = when {
        progress > 0.8f -> Color.Red
        progress > 0.6f -> CyberWarning
        else -> CyberAccent
    }

    Column(modifier = Modifier.width(90.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title, color = CyberGray, fontSize = 11.sp)
            Text("${current.toInt()}$unit", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = progress,
            color = progressColor,
            trackColor = CyberDark,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        )
    }
}

@Composable
fun CreateServerScreen(viewModel: HostViewModel) {
    val profile by viewModel.userProfile.collectAsState()
    var name by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("Node.js") }

    val currentTier = profile?.activeTier ?: "FREE"

    // Set specs details for preview
    val (storage, ram, cpu, disk) = when (currentTier) {
        "5.99$" -> listOf("4 GB", "3 GB", "1.5 GB", "2.5 GB")
        "8.99$" -> listOf("8 GB", "6 GB", "3 GB", "6 GB")
        "29.99$" -> listOf("100 GB", "64 GB", "16 GB", "32 GB")
        else -> listOf("700 MB", "1 GB", "500 MB", "1 GB") // FREE
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Spin Up Hosting Sandbox",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Container Host Name", color = CyberGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberAccent,
                        unfocusedBorderColor = CyberGray,
                        cursorColor = CyberAccent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("server_name_input"),
                    singleLine = true,
                    placeholder = { Text("my-node-service", color = CyberGray) }
                )

                Text(
                    text = "Select Runtime Environment",
                    fontSize = 14.sp,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedType == "Node.js") Color(0x3338BDF8) else CyberDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                1.dp,
                                if (selectedType == "Node.js") CyberAccent else Color.Transparent,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { selectedType = "Node.js" }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.Javascript,
                                contentDescription = null,
                                tint = CyberWarning,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Node.js", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Automatic NPM / Port", color = CyberGray, fontSize = 10.sp)
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedType == "Python") Color(0x3338BDF8) else CyberDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                1.dp,
                                if (selectedType == "Python") CyberAccent else Color.Transparent,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { selectedType = "Python" }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.Code,
                                contentDescription = null,
                                tint = CyberAccent,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Python", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Flask / requirements", color = CyberGray, fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // Selected Tier Limits Preview
        Card(
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Subscription Tier Limits allocation",
                    color = CyberPurple,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Limits are bound based on your active subscription tier: $currentTier",
                    color = CyberGray,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("RAM Allocation", color = CyberGray, fontSize = 12.sp)
                        Text(ram, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("Storage Volume", color = CyberGray, fontSize = 12.sp)
                        Text(storage, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("CPU Load Capacity", color = CyberGray, fontSize = 12.sp)
                        Text(cpu, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("System Disk", color = CyberGray, fontSize = 12.sp)
                        Text(disk, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Button(
            onClick = {
                if (name.isNotBlank()) {
                    viewModel.createServer(name, selectedType)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = CyberAccent),
            enabled = name.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("submit_server_button"),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("Launch isolated Sandbox Server", color = CyberDark, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ConsoleScreen(viewModel: HostViewModel, serverId: Int) {
    val context = LocalContext.current
    val server by viewModel.activeServer.collectAsState()
    val logs by viewModel.activeServerLogs.collectAsState()

    var activeTab by remember { mutableStateOf("METRICS") } // "METRICS", "FILES", "TERMINAL", "ENV"
    var commandInput by remember { mutableStateOf("") }
    var selectedFileToEdit by remember { mutableStateOf<String?>(null) }
    var fileContentInput by remember { mutableStateOf("") }

    if (server == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = CyberAccent)
        }
        return
    }

    val currServer = server!!

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top general status card
        Card(
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = currServer.name,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "URL: http://${currServer.domainName}",
                            color = CyberAccent,
                            fontSize = 12.sp
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (currServer.status == "RUNNING") "Active Live" else "Sleeping",
                            color = if (currServer.status == "RUNNING") CyberSuccess else Color.Red,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Switch(
                            checked = currServer.status == "RUNNING",
                            onCheckedChange = { viewModel.toggleServerStatus(serverId) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyberSuccess,
                                checkedTrackColor = Color(0x334ADE80)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Auto-Deploy (Hot Reload): ", color = CyberGray, fontSize = 12.sp)
                        Switch(
                            checked = currServer.autoDeploy,
                            onCheckedChange = { viewModel.toggleAutoDeploy(serverId, it) },
                            modifier = Modifier.scale(0.8f)
                        )
                    }

                    Button(
                        onClick = { viewModel.deleteServer(currServer) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0x22EF4444)),
                        shape = RoundedCornerShape(4.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("Terminate Server", color = Color.Red, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }

        // Sub Tabs
        ScrollableTabRow(
            selectedTabIndex = when (activeTab) {
                "METRICS" -> 0
                "FILES" -> 1
                "TERMINAL" -> 2
                else -> 3
            },
            containerColor = CyberDark,
            edgePadding = 0.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[when (activeTab) {
                        "METRICS" -> 0
                        "FILES" -> 1
                        "TERMINAL" -> 2
                        else -> 3
                    }]),
                    color = CyberAccent
                )
            }
        ) {
            Tab(
                selected = activeTab == "METRICS",
                onClick = { activeTab = "METRICS" },
                text = { Text("Live Metrics", color = Color.White) }
            )
            Tab(
                selected = activeTab == "FILES",
                onClick = { activeTab = "FILES" },
                text = { Text("Sandbox Files", color = Color.White) },
                modifier = Modifier.testTag("console_tab_files")
            )
            Tab(
                selected = activeTab == "TERMINAL",
                onClick = { activeTab = "TERMINAL" },
                text = { Text("Terminal Console", color = Color.White) },
                modifier = Modifier.testTag("console_tab_terminal")
            )
            Tab(
                selected = activeTab == "ENV",
                onClick = { activeTab = "ENV" },
                text = { Text("Environment", color = Color.White) }
            )
        }

        // Content
        Box(modifier = Modifier.weight(1f)) {
            when (activeTab) {
                "METRICS" -> {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    ) {
                        // Custom Gradient Resource Meter Cards
                        DetailedMeter(
                            title = "RAM Memory Sandbox Load",
                            used = currServer.ramUsageMb,
                            limit = currServer.ramLimitMb.toDouble(),
                            unit = "MB",
                            color = CyberPurple
                        )
                        DetailedMeter(
                            title = "CPU Multi-Thread Clock Load",
                            used = currServer.cpuUsageMb,
                            limit = currServer.cpuLoadLimitMb.toDouble(),
                            unit = "MB",
                            color = CyberAccent
                        )
                        DetailedMeter(
                            title = "SSD Volume Storage Space",
                            used = currServer.storageUsageMb,
                            limit = currServer.storageLimitMb.toDouble(),
                            unit = "MB",
                            color = CyberSuccess
                        )
                        DetailedMeter(
                            title = "Disk Read/Write Load Limit",
                            used = currServer.diskUsageMb,
                            limit = currServer.diskLimitMb.toDouble(),
                            unit = "MB",
                            color = CyberWarning
                        )
                    }
                }
                "FILES" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (selectedFileToEdit == null) {
                            Text(
                                "Manage local project source code below. Select a file to view or live edit. Saving code triggers auto hot-reloads.",
                                color = CyberGray,
                                fontSize = 12.sp
                            )

                            // ZIP file uploader launcher
                            val zipLauncher = rememberLauncherForActivityResult(
                                contract = ActivityResultContracts.GetContent()
                            ) { uri ->
                                if (uri != null) {
                                    try {
                                        val list = mutableListOf<Pair<String, String>>()
                                        context.contentResolver.openInputStream(uri)?.use { stream ->
                                            val zipStream = java.util.zip.ZipInputStream(stream)
                                            var entry = zipStream.nextEntry
                                            while (entry != null) {
                                                if (!entry.isDirectory) {
                                                    val parts = entry.name.split("/")
                                                    val name = parts.last()
                                                    if (name.endsWith(".js") || name.endsWith(".py") || 
                                                        name.endsWith(".json") || name.endsWith(".html") || 
                                                        name.endsWith(".css") || name.endsWith(".txt") ||
                                                        name.endsWith(".md")) {
                                                        
                                                        val baos = java.io.ByteArrayOutputStream()
                                                        val buffer = ByteArray(2048)
                                                        var len: Int
                                                        while (zipStream.read(buffer).also { len = it } != -1) {
                                                            baos.write(buffer, 0, len)
                                                        }
                                                        list.add(Pair(name, baos.toString("UTF-8")))
                                                    }
                                                }
                                                entry = zipStream.nextEntry
                                            }
                                        }
                                        if (list.isNotEmpty()) {
                                            viewModel.importZipContents(serverId, list)
                                            Toast.makeText(context, "Successfully extracted & hosted ${list.size} files!", Toast.LENGTH_LONG).show()
                                        } else {
                                            Toast.makeText(context, "No valid code files (.js, .py, .json, etc.) found in ZIP.", Toast.LENGTH_LONG).show()
                                        }
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Error reading ZIP: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }

                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0x154ADE80)),
                                border = BorderStroke(1.dp, CyberSuccess.copy(alpha = 0.4f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.UploadFile,
                                            contentDescription = null,
                                            tint = CyberSuccess
                                        )
                                        Text(
                                            "Real Host: Project ZIP Deployer",
                                            fontWeight = FontWeight.Bold,
                                            color = CyberSuccess,
                                            fontSize = 14.sp
                                        )
                                    }
                                    
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Select a ZIP file containing Node.js or Python code from your device to host it instantly in an isolated sandbox container.",
                                        color = CyberGray,
                                        fontSize = 11.sp
                                    )
                                    
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { zipLauncher.launch("application/zip") },
                                            colors = ButtonDefaults.buttonColors(containerColor = CyberSuccess),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(vertical = 8.dp)
                                        ) {
                                            Text("Upload ZIP Archive", color = CyberDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                        
                                        // Quick templates
                                        var showTemplatesMenu by remember { mutableStateOf(false) }
                                        Box(modifier = Modifier.weight(1f)) {
                                            Button(
                                                onClick = { showTemplatesMenu = true },
                                                colors = ButtonDefaults.buttonColors(containerColor = CyberPurple),
                                                shape = RoundedCornerShape(6.dp),
                                                modifier = Modifier.fillMaxWidth(),
                                                contentPadding = PaddingValues(vertical = 8.dp)
                                            ) {
                                                Text("⚡ Deploy Template", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }
                                            DropdownMenu(
                                                expanded = showTemplatesMenu,
                                                onDismissRequest = { showTemplatesMenu = false },
                                                modifier = Modifier.background(CyberCard)
                                            ) {
                                                DropdownMenuItem(
                                                    text = { Text("Node.js Real-time Socket App", color = Color.White, fontSize = 12.sp) },
                                                    onClick = {
                                                        showTemplatesMenu = false
                                                        viewModel.importZipContents(serverId, listOf(
                                                            Pair("package.json", """{
  "name": "socket-app",
  "version": "1.0.0",
  "main": "server.js",
  "dependencies": {
    "express": "^4.18.2",
    "socket.io": "^4.7.2"
  }
}"""),
                                                            Pair("server.js", """const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const port = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

io.on('connection', (socket) => {
  console.log('User connected: ' + socket.id);
  socket.on('chat_message', (msg) => {
    io.emit('chat_message', msg);
  });
});

http.listen(port, () => {
  console.log('Real-time chat listening on :' + port);
});"""),
                                                            Pair("index.html", """<!DOCTYPE html>
<html>
<head>
  <title>AeroHost Chat</title>
  <style>
    body { font-family: system-ui; background: #0c0f1d; color: #fff; display: flex; flex-direction: column; height: 100vh; margin: 0; padding: 20px; box-sizing: border-box; }
    h1 { color: #4ade80; margin-top: 0; }
    #chat { flex: 1; border: 1.5px solid #4ade80; border-radius: 8px; padding: 15px; overflow-y: auto; background: #181d31; }
    form { display: flex; gap: 10px; margin-top: 15px; }
    input { flex: 1; padding: 12px; border-radius: 6px; border: 1px solid #c084fc; background: #0c0f1d; color: #fff; }
    button { padding: 12px 24px; border-radius: 6px; border: none; background: #4ade80; color: #0c0f1d; font-weight: bold; cursor: pointer; }
  </style>
</head>
<body>
  <h1>AeroHost Real-time Node.js App</h1>
  <div id="chat">
    <p style="color:#a1a1aa">Welcome to live socket room. Send a message to test WebSocket...</p>
  </div>
  <form id="form">
    <input id="input" autocomplete="off" placeholder="Write message..." />
    <button>Send</button>
  </form>
  <script src="/socket.io/socket.io.js"></script>
  <script>
    var socket = io();
    var form = document.getElementById('form');
    var input = document.getElementById('input');
    var chat = document.getElementById('chat');

    form.addEventListener('submit', function(e) {
      e.preventDefault();
      if (input.value) {
        socket.emit('chat_message', input.value);
        input.value = '';
      }
    });

    socket.on('chat_message', function(msg) {
      var item = document.createElement('p');
      item.textContent = '💬 ' + msg;
      chat.appendChild(item);
      chat.scrollTop = chat.scrollHeight;
    });
  </script>
</body>
</html>""")
                                                        ))
                                                        Toast.makeText(context, "Node.js WebSocket Chat template deployed!", Toast.LENGTH_SHORT).show()
                                                    }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text("Python Flask ML API", color = Color.White, fontSize = 12.sp) },
                                                    onClick = {
                                                        showTemplatesMenu = false
                                                        viewModel.importZipContents(serverId, listOf(
                                                            Pair("requirements.txt", "Flask==3.0.0\nnumpy==1.26.0\nscikit-learn==1.3.1\n"),
                                                            Pair("server.py", """from flask import Flask, jsonify, request
import numpy as np

app = Flask(__name__)

@app.route('/')
def home():
    return jsonify({
        "status": "online",
        "service": "AeroHost Machine Learning Sandbox Engine",
        "runtime": "Python 3.11",
        "api_endpoints": ["/predict", "/stats"]
    })

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json() or {}
    feature = data.get('x', 0)
    prediction = float(2.5 * feature + 4.2)
    return jsonify({
        "feature_input": feature,
        "prediction_output": prediction,
        "confidence_score": 0.985
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)"""),
                                                            Pair("index.html", """<!DOCTYPE html>
<html>
<head>
    <title>Python ML API</title>
</head>
<body>
    <h1>AeroHost Python Flask ML App is active!</h1>
</body>
</html>""")
                                                        ))
                                                        Toast.makeText(context, "Python Flask ML API template deployed!", Toast.LENGTH_SHORT).show()
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            val files = viewModel.serversList.value.firstOrNull { it.id == serverId }?.serverFilesJson ?: ""
                            val fileList = remember(files) {
                                val list = mutableListOf<String>()
                                try {
                                    val arr = JSONArray(files)
                                    for (i in 0 until arr.length()) {
                                        list.add(arr.getJSONObject(i).getString("name"))
                                    }
                                } catch (e: Exception) {}
                                list
                            }

                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(fileList) { filename ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = CyberCard),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                selectedFileToEdit = filename
                                                fileContentInput = ""
                                                try {
                                                    val arr = JSONArray(currServer.serverFilesJson)
                                                    for (i in 0 until arr.length()) {
                                                        val o = arr.getJSONObject(i)
                                                        if (o.getString("name") == filename) {
                                                            fileContentInput = o.getString("content")
                                                            break
                                                        }
                                                    }
                                                } catch (e: Exception) {}
                                            }
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    Icons.Default.InsertDriveFile,
                                                    contentDescription = null,
                                                    tint = CyberAccent
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(filename, color = Color.White, fontWeight = FontWeight.Bold)
                                            }
                                            Text("Edit Code ›", color = CyberPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        } else {
                            // Code Editor Card
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Editing: ${selectedFileToEdit!!}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                TextButton(onClick = { selectedFileToEdit = null }) {
                                    Text("Back to Files", color = CyberAccent)
                                }
                            }

                            OutlinedTextField(
                                value = fileContentInput,
                                onValueChange = { fileContentInput = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                textStyle = androidx.compose.ui.text.TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    color = Color.White
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyberAccent,
                                    unfocusedBorderColor = CyberGray
                                )
                            )

                            Button(
                                onClick = {
                                    viewModel.updateServerFile(serverId, selectedFileToEdit!!, fileContentInput)
                                    selectedFileToEdit = null
                                    Toast.makeText(context, "Changes saved!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberSuccess),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Save File & Compile", color = CyberDark, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                "TERMINAL" -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            "Type 'help' to show all commands. Mode is: " + if (currServer.autoDeploy) "Auto Deploy" else "Manual Console Deploy",
                            color = CyberGray,
                            fontSize = 11.sp
                        )

                        // Console output block
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .background(Color.Black, RoundedCornerShape(8.dp))
                                .border(1.dp, CyberCard, RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            val scrollState = rememberScrollState()
                            LaunchedEffect(key1 = currServer.consoleOutput) {
                                scrollState.scrollTo(scrollState.maxValue)
                            }

                            Text(
                                text = currServer.consoleOutput,
                                color = CyberSuccess,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(scrollState)
                            )
                        }

                        // Input command row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = commandInput,
                                onValueChange = { commandInput = it },
                                textStyle = androidx.compose.ui.text.TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    color = Color.White
                                ),
                                placeholder = { Text("npm install...", color = CyberGray) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyberAccent,
                                    unfocusedBorderColor = CyberCard
                                ),
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(onSend = {
                                    viewModel.executeConsoleCommand(serverId, commandInput)
                                    commandInput = ""
                                })
                            )

                            Button(
                                onClick = {
                                    viewModel.executeConsoleCommand(serverId, commandInput)
                                    commandInput = ""
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberAccent),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Send", color = CyberDark, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                "ENV" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            "Environment details inside Docker isolated container",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )

                        EnvStatusRow("Node.js Runtime", "v20.11.0", true)
                        EnvStatusRow("NPM (Node Package)", "v10.2.4", true)
                        EnvStatusRow("Python Interpreter", "v3.11.6", true)
                        EnvStatusRow("Pip Package Manager", "v23.3.1", true)
                        EnvStatusRow("Docker Engine Sandbox", "v24.0.7-ce", true)
                        EnvStatusRow("SSL/TLS Engine Certificate", "Let's Encrypt (Live)", true)
                        EnvStatusRow("Database Drivers (SQLite/Cloud)", "Postgres/SQL/Room", true)
                    }
                }
            }
        }
    }
}

@Composable
fun EnvStatusRow(name: String, version: String, active: Boolean) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("Version: $version", color = CyberGray, fontSize = 11.sp)
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0x224ADE80)),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    "Installed & Validated",
                    color = CyberSuccess,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
fun DetailedMeter(title: String, used: Double, limit: Double, unit: String, color: Color) {
    val progress = if (limit > 0) (used / limit).toFloat().coerceIn(0f, 1f) else 0f

    Card(
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    text = "${used.toInt()}$unit / ${limit.toInt()}$unit",
                    color = color,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = progress,
                color = color,
                trackColor = CyberDark,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
            )

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Load level: ${(progress * 100).toInt()}% of allowed sandbox limit",
                color = CyberGray,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun ProfileScreen(viewModel: HostViewModel) {
    val context = LocalContext.current
    val profile by viewModel.userProfile.collectAsState()

    var nameInput by remember { mutableStateOf("") }
    var bioInput by remember { mutableStateOf("") }
    var websiteInput by remember { mutableStateOf("") }
    var twoFactorToggle by remember { mutableStateOf(false) }

    LaunchedEffect(profile) {
        profile?.let {
            nameInput = it.name
            bioInput = it.bio
            websiteInput = it.website
            twoFactorToggle = it.twoFactorEnabled
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Profile Settings",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Account Information (All details are saved locally)", color = CyberAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("Display Name", color = CyberGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberAccent,
                        unfocusedBorderColor = CyberGray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = bioInput,
                    onValueChange = { bioInput = it },
                    label = { Text("Personal Biography", color = CyberGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberAccent,
                        unfocusedBorderColor = CyberGray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = websiteInput,
                    onValueChange = { websiteInput = it },
                    label = { Text("Personal Website", color = CyberGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberAccent,
                        unfocusedBorderColor = CyberGray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Security Toggles
        Card(
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Security & Authenticators", color = CyberPurple, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Two-Factor Authentication (2FA)", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Secure console logins using secondary MFA code key.", color = CyberGray, fontSize = 11.sp)
                    }

                    Switch(
                        checked = twoFactorToggle,
                        onCheckedChange = { twoFactorToggle = it }
                    )
                }
            }
        }

        Button(
            onClick = {
                viewModel.updateProfileInfo(nameInput, bioInput, websiteInput, twoFactorToggle)
                Toast.makeText(context, "Profile updated securely!", Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = CyberAccent),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Save Settings", color = CyberDark, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun PaymentScreen(viewModel: HostViewModel) {
    val codesList by viewModel.redeemCodesList.collectAsState()
    val paymentMsg by viewModel.paymentMsg.collectAsState()
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    var redeemInput by remember { mutableStateOf("") }
    var activeSubTab by remember { mutableStateOf("CREDIT_CARD") } // CREDIT_CARD, PAYPAL, REDEEM

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Upgrade Subscription Tier",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Text(
            text = "Select your desired premium capability and checkout. Enjoy uncompromised resource bounds.",
            color = CyberGray,
            fontSize = 12.sp
        )

        // Subtabs for payment types
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { activeSubTab = "CREDIT_CARD" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeSubTab == "CREDIT_CARD") CyberAccent else CyberCard
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("Visa / Card", color = if (activeSubTab == "CREDIT_CARD") CyberDark else Color.White, fontSize = 11.sp)
            }
            Button(
                onClick = { activeSubTab = "PAYPAL" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeSubTab == "PAYPAL") CyberAccent else CyberCard
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("PayPal", color = if (activeSubTab == "PAYPAL") CyberDark else Color.White, fontSize = 11.sp)
            }
            Button(
                onClick = { activeSubTab = "REDEEM" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeSubTab == "REDEEM") CyberAccent else CyberCard
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("payment_tab_redeem")
            ) {
                Text("Promo Code", color = if (activeSubTab == "REDEEM") CyberDark else Color.White, fontSize = 11.sp)
            }
        }

        if (paymentMsg != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = paymentMsg ?: "",
                    color = CyberSuccess,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            when (activeSubTab) {
                "CREDIT_CARD" -> {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    ) {
                        VisaTierCard(
                            price = "5.99$",
                            tier = "AERO-PRO (Basic)",
                            ram = "3 GB",
                            storage = "4 GB",
                            cpu = "1.5 GB",
                            disk = "2.5 GB",
                            onPay = { viewModel.payWithCard("5.99$") }
                        )
                        VisaTierCard(
                            price = "8.99$",
                            tier = "AERO-PLUS (Intermediate)",
                            ram = "6 GB",
                            storage = "8 GB",
                            cpu = "3 GB",
                            disk = "6 GB",
                            onPay = { viewModel.payWithCard("8.99$") }
                        )
                        VisaTierCard(
                            price = "29.99$",
                            tier = "AERO-ENTERPRISE (Infinite)",
                            ram = "64 GB",
                            storage = "100 GB",
                            cpu = "16 GB",
                            disk = "32 GB",
                            onPay = { viewModel.payWithCard("29.99$") }
                        )
                    }
                }
                "PAYPAL" -> {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    ) {
                        PayPalTierCard(
                            price = "5.99$",
                            tier = "AERO-PRO (Basic)",
                            ram = "3 GB",
                            storage = "4 GB",
                            onPay = { viewModel.payWithPayPal("5.99$") }
                        )
                        PayPalTierCard(
                            price = "8.99$",
                            tier = "AERO-PLUS (Intermediate)",
                            ram = "6 GB",
                            storage = "8 GB",
                            onPay = { viewModel.payWithPayPal("8.99$") }
                        )
                        PayPalTierCard(
                            price = "29.99$",
                            tier = "AERO-ENTERPRISE (Infinite)",
                            ram = "64 GB",
                            storage = "100 GB",
                            onPay = { viewModel.payWithPayPal("29.99$") }
                        )
                    }
                }
                "REDEEM" -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = redeemInput,
                                onValueChange = { redeemInput = it },
                                placeholder = { Text("Paste code (e.g., DXCVYIDB...)", color = CyberGray) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyberAccent,
                                    unfocusedBorderColor = CyberCard
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("redeem_code_input"),
                                singleLine = true
                            )

                            Button(
                                onClick = {
                                    viewModel.redeemCode(redeemInput)
                                    redeemInput = ""
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberAccent),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("redeem_submit_button")
                            ) {
                                Text("Apply", color = CyberDark, fontWeight = FontWeight.Bold)
                            }
                        }

                        Text(
                            text = "Available Test Promotional Codes (20 Seeded in database):",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            items(codesList) { code ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = CyberCard),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = code.code,
                                                fontWeight = FontWeight.Bold,
                                                color = if (code.isRedeemed) CyberGray else Color.White,
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                text = "Unlocks: ${code.tier} Plan  |  " + if (code.isRedeemed) "Redeemed by ${code.redeemedByEmail}" else "Available to use",
                                                color = if (code.isRedeemed) Color.Red else CyberSuccess,
                                                fontSize = 11.sp
                                            )
                                        }

                                        if (!code.isRedeemed) {
                                            IconButton(
                                                onClick = {
                                                    clipboardManager.setText(AnnotatedString(code.code))
                                                    Toast.makeText(context, "Code copied!", Toast.LENGTH_SHORT).show()
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.ContentCopy,
                                                    contentDescription = "Copy code",
                                                    tint = CyberAccent,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VisaTierCard(price: String, tier: String, ram: String, storage: String, cpu: String, disk: String, onPay: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(tier, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Specs: RAM $ram, Storage $storage, CPU $cpu, Disk $disk", color = CyberGray, fontSize = 11.sp)
                }
                Text(price, color = CyberAccent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onPay,
                colors = ButtonDefaults.buttonColors(containerColor = CyberAccent),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("Checkout with Credit Card", color = CyberDark, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PayPalTierCard(price: String, tier: String, ram: String, storage: String, onPay: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(tier, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Specs: RAM $ram, Storage $storage", color = CyberGray, fontSize = 11.sp)
                }
                Text(price, color = CyberPurple, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onPay,
                colors = ButtonDefaults.buttonColors(containerColor = CyberPurple),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("Pay with PayPal Secure", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun TermuxGuideScreen(viewModel: HostViewModel) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    val packageJsonContent = """{
  "name": "termux-node-app",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "express": "^4.18.2"
  }
}"""

    val indexHtmlContent = """<!DOCTYPE html>
<html>
<head>
    <title>AeroHost Termux</title>
    <style>
        body { background: #0f1115; color: #fff; text-align: center; font-family: monospace; padding-top: 10%; }
        h1 { color: #38bdf8; }
    </style>
</head>
<body>
    <h1>AeroHost Isolated Container Test</h1>
    <p>Status: Successfully Hosted on Termux!</p>
</body>
</html>"""

    val serverJsContent = """const express = require('express');
const app = express();
const path = require('path');
const port = 3000;

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(port, () => {
    console.log('Server is running locally at http://localhost:' + port);
});"""

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Termux Deployment Tutorial",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Text(
            text = "To test and deploy your files inside Android Termux easily, follow the step-by-step instructions below.",
            color = CyberGray,
            fontSize = 13.sp
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Step 1: Install Node.js on Termux",
                    color = CyberAccent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Launch Termux application and execute these terminal setup commands:",
                    color = CyberGray,
                    fontSize = 12.sp
                )

                CodeBlock(
                    command = "pkg update && pkg upgrade -y\npkg install nodejs -y",
                    onCopy = {
                        clipboardManager.setText(AnnotatedString("pkg update && pkg upgrade -y && pkg install nodejs -y"))
                        Toast.makeText(context, "Command copied!", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Step 2: Create Project Files",
                    color = CyberPurple,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Create these 3 files inside your project directory (e.g., using nano or vim):",
                    color = CyberGray,
                    fontSize = 12.sp
                )

                FileGuideBlock("package.json", packageJsonContent, clipboardManager, context)
                FileGuideBlock("index.html", indexHtmlContent, clipboardManager, context)
                FileGuideBlock("server.js", serverJsContent, clipboardManager, context)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Step 3: Launch your server",
                    color = CyberSuccess,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Install the node express modules and spin up the backend server locally:",
                    color = CyberGray,
                    fontSize = 12.sp
                )

                CodeBlock(
                    command = "npm install\nnode server.js",
                    onCopy = {
                        clipboardManager.setText(AnnotatedString("npm install && node server.js"))
                        Toast.makeText(context, "Command copied!", Toast.LENGTH_SHORT).show()
                    }
                )

                Text(
                    text = "Open http://localhost:3000 inside your web browser to access your hosted app!",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun CodeBlock(command: String, onCopy: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black, RoundedCornerShape(6.dp))
            .border(1.dp, CyberCard, RoundedCornerShape(6.dp))
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = command,
            color = CyberSuccess,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            modifier = Modifier.weight(1f)
        )

        IconButton(onClick = onCopy) {
            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyberAccent, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
fun FileGuideBlock(
    filename: String,
    content: String,
    clipboardManager: androidx.compose.ui.platform.ClipboardManager,
    context: android.content.Context
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(filename, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            TextButton(
                onClick = {
                    clipboardManager.setText(AnnotatedString(content))
                    Toast.makeText(context, "$filename content copied!", Toast.LENGTH_SHORT).show()
                },
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("Copy Content", color = CyberAccent, fontSize = 11.sp)
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black, RoundedCornerShape(4.dp))
                .padding(6.dp)
        ) {
            Text(
                content,
                color = CyberGray,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 6
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
    }
}
