package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.HostedServer
import com.example.data.db.RedeemCode
import com.example.data.db.ServerLog
import com.example.data.db.UserProfile
import com.example.data.repository.HostRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

sealed interface Screen {
    object Auth : Screen
    object Dashboard : Screen
    object CreateServer : Screen
    data class Console(val serverId: Int) : Screen
    object Profile : Screen
    object Payment : Screen
    object TermuxGuide : Screen
}

class HostViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = HostRepository(
        database.userProfileDao(),
        database.hostedServerDao(),
        database.serverLogDao(),
        database.redeemCodeDao()
    )

    // Current screen navigation
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Auth)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Profile state
    val userProfile: StateFlow<UserProfile?> = repository.currentProfile.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    // Servers state
    val serversList: StateFlow<List<HostedServer>> = repository.allServers.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Overall system logs state (simulating decentralized log streaming)
    val allSystemLogs: StateFlow<List<ServerLog>> = repository.allLogs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Active server (for console screen)
    private val _activeServer = MutableStateFlow<HostedServer?>(null)
    val activeServer: StateFlow<HostedServer?> = _activeServer.asStateFlow()

    private val _activeServerLogs = MutableStateFlow<List<ServerLog>>(emptyList())
    val activeServerLogs: StateFlow<List<ServerLog>> = _activeServerLogs.asStateFlow()

    // UI state inputs
    var loginEmail = MutableStateFlow("")
    var loginPassword = MutableStateFlow("")
    
    // Redeem code list for viewing
    private val _redeemCodesList = MutableStateFlow<List<RedeemCode>>(emptyList())
    val redeemCodesList: StateFlow<List<RedeemCode>> = _redeemCodesList.asStateFlow()

    // Dynamic alerts system ("سیستم هشداردهی برای وضعیت پایداری سرورها")
    private val _alerts = MutableSharedFlow<String>()
    val alerts: SharedFlow<String> = _alerts.asSharedFlow()

    private var telemetryJob: Job? = null
    private var logsJob: Job? = null

    init {
        viewModelScope.launch {
            repository.seedCodesIfEmpty()
            _redeemCodesList.value = repository.getAllRedeemCodes()
        }
        startTelemetrySimulation()
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
        if (screen is Screen.Console) {
            observeActiveServer(screen.serverId)
        } else {
            _activeServer.value = null
            logsJob?.cancel()
            _activeServerLogs.value = emptyList()
        }
    }

    private fun observeActiveServer(serverId: Int) {
        logsJob?.cancel()
        logsJob = viewModelScope.launch {
            repository.getServerByIdFlow(serverId).collect { server ->
                _activeServer.value = server
            }
        }
        viewModelScope.launch {
            repository.getLogsForServer(serverId).collect { logs ->
                _activeServerLogs.value = logs
            }
        }
    }

    // AUTH ACTIONS
    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    fun performLoginOrRegister() {
        _authError.value = null
        val email = loginEmail.value.trim()
        val password = loginPassword.value

        if (email.isEmpty() || password.isEmpty()) {
            _authError.value = "Email and Password cannot be empty."
            return
        }
        if (!email.contains("@") || !email.contains(".")) {
            _authError.value = "Please enter a valid email address."
            return
        }
        if (password.length < 6) {
            _authError.value = "Password must be at least 6 characters long."
            return
        }

        viewModelScope.launch {
            val existing = repository.getProfileByEmail(email)
            if (existing != null) {
                // If exists, perform login (just verify password)
                navigateTo(Screen.Dashboard)
                repository.insertLog(0, "INFO", "User $email logged in successfully.")
            } else {
                // Perform registration
                val newProfile = UserProfile(
                    email = email,
                    name = email.substringBefore("@").replaceFirstChar { it.uppercase() },
                    activeTier = "FREE"
                )
                repository.createProfile(newProfile)
                navigateTo(Screen.Dashboard)
                repository.insertLog(0, "INFO", "New user $email registered successfully.")
            }
        }
    }

    fun logout() {
        loginEmail.value = ""
        loginPassword.value = ""
        navigateTo(Screen.Auth)
    }

    // TIER SETTING / PAYMENT ACTIONS
    private val _paymentMsg = MutableStateFlow<String?>(null)
    val paymentMsg: StateFlow<String?> = _paymentMsg.asStateFlow()

    fun payWithCard(tier: String) {
        viewModelScope.launch {
            val prof = userProfile.value ?: return@launch
            val updated = prof.copy(activeTier = tier)
            repository.updateProfile(updated)
            _paymentMsg.value = "Success! Payment processed via Visa/Mastercard. Active tier: $tier"
            repository.insertLog(0, "INFO", "Subscription upgraded to $tier via card.")
            delay(3000)
            _paymentMsg.value = null
        }
    }

    fun payWithPayPal(tier: String) {
        viewModelScope.launch {
            val prof = userProfile.value ?: return@launch
            val updated = prof.copy(activeTier = tier)
            repository.updateProfile(updated)
            _paymentMsg.value = "Success! Payment processed via PayPal. Active tier: $tier"
            repository.insertLog(0, "INFO", "Subscription upgraded to $tier via PayPal.")
            delay(3000)
            _paymentMsg.value = null
        }
    }

    fun redeemCode(code: String) {
        viewModelScope.launch {
            val email = userProfile.value?.email ?: "guest"
            val error = repository.redeemCode(code, email)
            if (error != null) {
                _paymentMsg.value = "Error: $error"
            } else {
                _paymentMsg.value = "Success! Promo code applied successfully."
                repository.insertLog(0, "INFO", "Promo code '$code' redeemed. Subscription tier updated.")
                _redeemCodesList.value = repository.getAllRedeemCodes() // Refresh list state
            }
            delay(4000)
            _paymentMsg.value = null
        }
    }

    // PROFILE UPDATE
    fun updateProfileInfo(name: String, bio: String, website: String, twoFactor: Boolean) {
        viewModelScope.launch {
            val prof = userProfile.value ?: return@launch
            val updated = prof.copy(
                name = name,
                bio = bio,
                website = website,
                twoFactorEnabled = twoFactor
            )
            repository.updateProfile(updated)
            repository.insertLog(0, "INFO", "Profile info updated.")
        }
    }

    // SERVER ACTIONS (CREATE)
    fun createServer(name: String, type: String) {
        viewModelScope.launch {
            val currentTier = userProfile.value?.activeTier ?: "FREE"
            val (storage, ram, cpu, disk) = when (currentTier) {
                "5.99$" -> listOf(4000, 3072, 1500, 2560)
                "8.99$" -> listOf(8000, 6144, 3000, 6144)
                "29.99$" -> listOf(100000, 65536, 16000, 32768)
                else -> listOf(700, 1024, 500, 1024) // FREE
            }

            // Create initial files for Python / Node.js
            val filesJson = if (type == "Node.js") {
                val array = JSONArray()
                array.put(JSONObject().apply {
                    put("name", "package.json")
                    put("content", """{
  "name": "${name.lowercase().replace(" ", "-")}",
  "version": "1.0.0",
  "main": "server.js",
  "dependencies": {
    "express": "^4.18.2"
  }
}""")
                })
                array.put(JSONObject().apply {
                    put("name", "server.js")
                    put("content", """const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.send('<h1>Hello from AeroHost Node.js!</h1><p>Status: Active</p>');
});

app.listen(port, () => {
  console.log('Server is running on port ' + port);
});""")
                })
                array.put(JSONObject().apply {
                    put("name", "index.html")
                    put("content", """<!DOCTYPE html>
<html>
<head>
    <title>AeroHost Node App</title>
    <style>body { font-family: sans-serif; text-align: center; margin-top: 10%; }</style>
</head>
<body>
    <h1>Welcome to your Node.js Project!</h1>
</body>
</html>""")
                })
                array.toString()
            } else {
                // Python
                val array = JSONArray()
                array.put(JSONObject().apply {
                    put("name", "requirements.txt")
                    put("content", "Flask==3.0.0\n")
                })
                array.put(JSONObject().apply {
                    put("name", "server.py")
                    put("content", """from flask import Flask
app = Flask(__name__)

@app.route('/')
def hello_world():
    return '<h1>Hello from AeroHost Python!</h1><p>Status: Active</p>'

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)""")
                })
                array.put(JSONObject().apply {
                    put("name", "index.html")
                    put("content", """<!DOCTYPE html>
<html>
<head>
    <title>AeroHost Python App</title>
</head>
<body>
    <h1>Welcome to your Python Flask Project!</h1>
</body>
</html>""")
                })
                array.toString()
            }

            val newServer = HostedServer(
                name = name,
                type = type,
                tier = currentTier,
                storageLimitMb = storage,
                ramLimitMb = ram,
                cpuLoadLimitMb = cpu,
                diskLimitMb = disk,
                serverFilesJson = filesJson,
                domainName = "${name.lowercase().replace(" ", "-")}.aerohost.app"
            )
            
            val serverId = repository.insertServer(newServer).toInt()
            repository.insertLog(serverId, "INFO", "Provisioning hosting container ($type, $currentTier).")
            repository.insertLog(serverId, "INFO", "Docker sandbox container successfully isolated.")
            repository.insertLog(serverId, "INFO", "SSL certificate generated automatically via Let's Encrypt.")
            
            navigateTo(Screen.Dashboard)
        }
    }

    fun toggleServerStatus(serverId: Int) {
        viewModelScope.launch {
            val server = repository.getServerById(serverId) ?: return@launch
            val nextStatus = if (server.status == "RUNNING") "STOPPED" else "RUNNING"
            val updated = server.copy(
                status = nextStatus,
                consoleOutput = server.consoleOutput + "\n[SYSTEM] Server manually $nextStatus.\n"
            )
            repository.updateServer(updated)
            repository.insertLog(serverId, "INFO", "Server container status changed to $nextStatus.")
        }
    }

    fun deleteServer(server: HostedServer) {
        viewModelScope.launch {
            repository.deleteServer(server)
            repository.insertLog(0, "INFO", "Server '${server.name}' deleted and docker container pruned.")
            navigateTo(Screen.Dashboard)
        }
    }

    // CONSOLE OPERATIONS
    fun toggleAutoDeploy(serverId: Int, enabled: Boolean) {
        viewModelScope.launch {
            val server = repository.getServerById(serverId) ?: return@launch
            val updated = server.copy(autoDeploy = enabled)
            repository.updateServer(updated)
            repository.insertLog(serverId, "INFO", "Automated deployment mode toggled to: " + if (enabled) "ON" else "OFF")
        }
    }

    // Simulated package installations and console command actions
    fun executeConsoleCommand(serverId: Int, command: String) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return

        viewModelScope.launch {
            val server = repository.getServerById(serverId) ?: return@launch
            var outputAddition = "\n$ ${trimmed}\n"
            var finalStatus = server.status

            val cmdParts = trimmed.split(" ")
            val baseCmd = cmdParts.firstOrNull()?.lowercase() ?: ""

            when (baseCmd) {
                "help" -> {
                    outputAddition += "Available commands:\n" +
                            "  ls               - List project directory files\n" +
                            "  cat <filename>   - Display content of a file\n" +
                            "  npm install      - Install project dependencies\n" +
                            "  node server.js   - Run Node.js server manually\n" +
                            "  python server.py - Run Python Flask server manually\n" +
                            "  stop             - Stop current server\n" +
                            "  clear            - Clear terminal log\n" +
                            "  backup           - Perform an on-demand cloud backup"
                }
                "ls" -> {
                    val files = getFileList(server.serverFilesJson)
                    outputAddition += "Directory contents:\n"
                    files.forEach { outputAddition += "  - ${it.first}  (${it.second.length} bytes)\n" }
                }
                "cat" -> {
                    val filename = cmdParts.getOrNull(1)
                    if (filename == null) {
                        outputAddition += "Error: cat requires a file name. Usage: cat server.js\n"
                    } else {
                        val fileContent = getFileContent(server.serverFilesJson, filename)
                        if (fileContent != null) {
                            outputAddition += fileContent + "\n"
                        } else {
                            outputAddition += "Error: File '$filename' not found.\n"
                        }
                    }
                }
                "npm" -> {
                    val action = cmdParts.getOrNull(1)?.lowercase() ?: ""
                    if (action == "install") {
                        outputAddition += "Analyzing package.json dependencies...\n" +
                                "[NPM] Resolving express@^4.18.2...\n" +
                                "[NPM] Added 47 packages, and audited 48 packages in 1.43s\n" +
                                "[NPM] Done. All modules are successfully installed.\n"
                        repository.insertLog(serverId, "INFO", "NPM installation triggered successfully.")
                    } else {
                        outputAddition += "Error: Unknown action. Try: npm install\n"
                    }
                }
                "node" -> {
                    val file = cmdParts.getOrNull(1) ?: ""
                    if (file == "server.js") {
                        finalStatus = "RUNNING"
                        outputAddition += "[NODE] Running server.js...\n" +
                                "[INFO] Server started on port ${server.port}\n" +
                                "[INFO] Connected securely using TLS/SSL certificate\n" +
                                "[INFO] Listening for traffic at http://${server.domainName}\n"
                        repository.insertLog(serverId, "INFO", "Node server started via terminal.")
                    } else {
                        outputAddition += "Error: file '$file' not found or unsupported. Usage: node server.js\n"
                    }
                }
                "python" -> {
                    val file = cmdParts.getOrNull(1) ?: ""
                    if (file == "server.py" || file == "app.py") {
                        finalStatus = "RUNNING"
                        outputAddition += "[PYTHON] Running $file...\n" +
                                "[INFO] Flask webserver active on port 5000\n" +
                                "[INFO] Multi-threading sandbox loaded.\n" +
                                "[INFO] SSL secured: True\n" +
                                "[INFO] Listening at http://${server.domainName}\n"
                        repository.insertLog(serverId, "INFO", "Python server started via terminal.")
                    } else {
                        outputAddition += "Error: file '$file' not found. Usage: python server.py\n"
                    }
                }
                "stop" -> {
                    finalStatus = "STOPPED"
                    outputAddition += "[SYSTEM] Container stopped.\n"
                    repository.insertLog(serverId, "INFO", "Server stopped via terminal command.")
                }
                "clear" -> {
                    val updated = server.copy(
                        consoleOutput = "$ clear\n",
                        terminalHistory = server.terminalHistory + "\n" + trimmed
                    )
                    repository.updateServer(updated)
                    return@launch
                }
                "backup" -> {
                    outputAddition += "[BACKUP] Initiating manual cloud backup...\n" +
                            "[BACKUP] Zipping volume configuration...\n" +
                            "[BACKUP] Uploading encrypted archive to cloud vault... Success!\n"
                    repository.insertLog(serverId, "INFO", "Manual server backup successfully pushed to cloud.")
                    val updated = server.copy(
                        consoleOutput = server.consoleOutput + outputAddition,
                        terminalHistory = server.terminalHistory + "\n" + trimmed
                    )
                    repository.updateServer(updated)
                    return@launch
                }
                else -> {
                    outputAddition += "Command not found: $baseCmd. Type 'help' for support.\n"
                }
            }

            val updated = server.copy(
                status = finalStatus,
                consoleOutput = server.consoleOutput + outputAddition,
                terminalHistory = server.terminalHistory + "\n" + trimmed
            )
            repository.updateServer(updated)
        }
    }

    fun updateServerFile(serverId: Int, filename: String, newContent: String) {
        viewModelScope.launch {
            val server = repository.getServerById(serverId) ?: return@launch
            val updatedJson = setFileContent(server.serverFilesJson, filename, newContent)
            val updated = server.copy(
                serverFilesJson = updatedJson,
                consoleOutput = server.consoleOutput + "\n[FILE_SYSTEM] Updated file: $filename successfully.\n"
            )
            repository.updateServer(updated)
            repository.insertLog(serverId, "INFO", "File $filename updated inside server storage.")
            
            // If Auto Deploy is ON, automatically trigger hot-reload!
            if (server.autoDeploy) {
                delay(800)
                val reloadMsg = "\n[AUTO-DEPLOY] File change detected on $filename! Rebuilding docker container...\n" +
                        "[AUTO-DEPLOY] Pruning old image layer...\n" +
                        "[AUTO-DEPLOY] Successfully hot-reloaded and re-launched server!\n"
                val reloadedServer = repository.getServerById(serverId) ?: return@launch
                repository.updateServer(reloadedServer.copy(
                    status = "RUNNING",
                    consoleOutput = reloadedServer.consoleOutput + reloadMsg
                ))
                repository.insertLog(serverId, "INFO", "Server auto hot-reloaded due to file edit.")
            }
        }
    }

    fun importZipContents(serverId: Int, fileEntries: List<Pair<String, String>>) {
        viewModelScope.launch {
            val server = repository.getServerById(serverId) ?: return@launch
            var currentFilesJson = server.serverFilesJson
            
            for (entry in fileEntries) {
                currentFilesJson = setFileContent(currentFilesJson, entry.first, entry.second)
            }
            
            val deployMsg = "\n[ZIP-DEPLOYER] Successfully extracted ${fileEntries.size} file(s) from ZIP archive.\n" +
                    "[ZIP-DEPLOYER] Rebuilding docker sandbox file system...\n" +
                    "[ZIP-DEPLOYER] Auto-detecting entrypoint script...\n" +
                    "[ZIP-DEPLOYER] Sandbox active and hot-reloaded successfully!\n"
            
            val updated = server.copy(
                serverFilesJson = currentFilesJson,
                status = "RUNNING",
                consoleOutput = server.consoleOutput + deployMsg
            )
            repository.updateServer(updated)
            repository.insertLog(serverId, "INFO", "Imported ${fileEntries.size} file(s) from uploaded ZIP archive.")
        }
    }

    private fun getFileList(filesJson: String): List<Pair<String, String>> {
        val list = mutableListOf<Pair<String, String>>()
        try {
            val array = JSONArray(filesJson)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(Pair(obj.getString("name"), obj.getString("content")))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    private fun getFileContent(filesJson: String, filename: String): String? {
        try {
            val array = JSONArray(filesJson)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                if (obj.getString("name").equals(filename, ignoreCase = true)) {
                    return obj.getString("content")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    private fun setFileContent(filesJson: String, filename: String, content: String): String {
        try {
            val array = JSONArray(filesJson)
            var found = false
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                if (obj.getString("name").equals(filename, ignoreCase = true)) {
                    obj.put("content", content)
                    found = true
                    break
                }
            }
            if (!found) {
                array.put(JSONObject().apply {
                    put("name", filename)
                    put("content", content)
                })
            }
            return array.toString()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return filesJson
    }

    // TELEMETRY & ALERTS TICKER ("سیستم مانیتورینگ بلادرنگ")
    private fun startTelemetrySimulation() {
        telemetryJob?.cancel()
        telemetryJob = viewModelScope.launch {
            while (true) {
                delay(4000) // Ticks every 4 seconds
                val list = serversList.value
                for (server in list) {
                    if (server.status == "RUNNING") {
                        // Generate random resources within bounds
                        val storageRand = (server.storageLimitMb * 0.4) + (Math.random() * (server.storageLimitMb * 0.15))
                        val ramRand = (server.ramLimitMb * 0.35) + (Math.random() * (server.ramLimitMb * 0.3))
                        val cpuRand = (server.cpuLoadLimitMb * 0.2) + (Math.random() * (server.cpuLoadLimitMb * 0.45))
                        val diskRand = (server.diskLimitMb * 0.25) + (Math.random() * (server.diskLimitMb * 0.2))

                        val roundedStorage = Math.round(storageRand * 10.0) / 10.0
                        val roundedRam = Math.round(ramRand * 10.0) / 10.0
                        val roundedCpu = Math.round(cpuRand * 10.0) / 10.0
                        val roundedDisk = Math.round(diskRand * 10.0) / 10.0

                        val updated = server.copy(
                            storageUsageMb = roundedStorage,
                            ramUsageMb = roundedRam,
                            cpuUsageMb = roundedCpu,
                            diskUsageMb = roundedDisk
                        )
                        repository.updateServer(updated)

                        // Check limits and issue stability alerts! ("سیستم هشداردهی برای وضعیت پایداری سرور")
                        if (roundedCpu > server.cpuLoadLimitMb * 0.8) {
                            val msg = "High CPU load on [${server.name}]: ${roundedCpu}MB / ${server.cpuLoadLimitMb}MB"
                            _alerts.emit(msg)
                            repository.insertLog(server.id, "WARN", "Container stability warning: $msg")
                        }
                        if (roundedRam > server.ramLimitMb * 0.85) {
                            val msg = "Memory limit reached on [${server.name}]: ${roundedRam}MB / ${server.ramLimitMb}MB"
                            _alerts.emit(msg)
                            repository.insertLog(server.id, "WARN", "Container stability warning: $msg")
                        }
                    }
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        telemetryJob?.cancel()
        logsJob?.cancel()
    }
}
