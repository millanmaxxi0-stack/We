package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profiles LIMIT 1")
    fun getProfile(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profiles WHERE email = :email LIMIT 1")
    suspend fun getProfileByEmail(email: String): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: UserProfile)

    @Update
    suspend fun updateProfile(profile: UserProfile)
}

@Dao
interface HostedServerDao {
    @Query("SELECT * FROM hosted_servers ORDER BY createdAt DESC")
    fun getAllServers(): Flow<List<HostedServer>>

    @Query("SELECT * FROM hosted_servers WHERE id = :id LIMIT 1")
    fun getServerByIdFlow(id: Int): Flow<HostedServer?>

    @Query("SELECT * FROM hosted_servers WHERE id = :id LIMIT 1")
    suspend fun getServerById(id: Int): HostedServer?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServer(server: HostedServer): Long

    @Update
    suspend fun updateServer(server: HostedServer)

    @Delete
    suspend fun deleteServer(server: HostedServer)
}

@Dao
interface ServerLogDao {
    @Query("SELECT * FROM server_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<ServerLog>>

    @Query("SELECT * FROM server_logs WHERE serverId = :serverId ORDER BY timestamp DESC")
    fun getLogsByServerId(serverId: Int): Flow<List<ServerLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ServerLog)

    @Query("DELETE FROM server_logs WHERE serverId = :serverId")
    suspend fun clearLogsByServerId(serverId: Int)
}

@Dao
interface RedeemCodeDao {
    @Query("SELECT * FROM redeem_codes")
    suspend fun getAllCodes(): List<RedeemCode>

    @Query("SELECT * FROM redeem_codes WHERE code = :code LIMIT 1")
    suspend fun getCode(code: String): RedeemCode?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCodes(codes: List<RedeemCode>)

    @Update
    suspend fun updateCode(code: RedeemCode)
}
