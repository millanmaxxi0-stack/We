package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profiles")
data class UserProfile(
    @PrimaryKey val email: String,
    val name: String,
    val avatarUrl: String = "",
    val activeTier: String = "FREE", // "FREE", "5.99$", "8.99$", "29.99$"
    val website: String = "",
    val bio: String = "",
    val twoFactorEnabled: Boolean = false,
    val twoFactorSecret: String = "AEROHOST-MFA-SECRET-XYZ",
    val backupFrequency: String = "Daily", // Daily, Weekly, Manual
    val lastBackupTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "hosted_servers")
data class HostedServer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val type: String, // "Node.js" or "Python"
    val tier: String, // "FREE", "5.99$", "8.99$", "29.99$"
    val status: String = "STOPPED", // "RUNNING", "STOPPED", "DEPLOYING"
    val autoDeploy: Boolean = true,
    val storageLimitMb: Int,
    val ramLimitMb: Int,
    val cpuLoadLimitMb: Int, // The CPU load metric in MBs as requested
    val diskLimitMb: Int,
    val storageUsageMb: Double = 0.0,
    val ramUsageMb: Double = 0.0,
    val cpuUsageMb: Double = 0.0,
    val diskUsageMb: Double = 0.0,
    val serverFilesJson: String = "", // JSON string containing file list and content
    val terminalHistory: String = "", // Command history
    val consoleOutput: String = "Server initialized and ready to deploy.\n",
    val port: Int = 3000,
    val isSslEnabled: Boolean = true,
    val domainName: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "server_logs")
data class ServerLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val serverId: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val level: String, // "INFO", "WARN", "ERROR"
    val message: String,
    val distributedNode: String = "Node-US-East" // Simulated decentralized node logging
)

@Entity(tableName = "redeem_codes")
data class RedeemCode(
    @PrimaryKey val code: String,
    val tier: String, // "FREE", "5.99$", "8.99$", "29.99$"
    val isRedeemed: Boolean = false,
    val redeemedByEmail: String = ""
)
