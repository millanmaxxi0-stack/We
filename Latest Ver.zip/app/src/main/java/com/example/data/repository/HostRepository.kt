package com.example.data.repository

import com.example.data.db.HostedServer
import com.example.data.db.HostedServerDao
import com.example.data.db.RedeemCode
import com.example.data.db.RedeemCodeDao
import com.example.data.db.ServerLog
import com.example.data.db.ServerLogDao
import com.example.data.db.UserProfile
import com.example.data.db.UserProfileDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class HostRepository(
    private val profileDao: UserProfileDao,
    private val serverDao: HostedServerDao,
    private val logDao: ServerLogDao,
    private val redeemDao: RedeemCodeDao
) {
    val currentProfile: Flow<UserProfile?> = profileDao.getProfile()
    val allServers: Flow<List<HostedServer>> = serverDao.getAllServers()
    val allLogs: Flow<List<ServerLog>> = logDao.getAllLogs()

    suspend fun getProfileByEmail(email: String): UserProfile? = profileDao.getProfileByEmail(email)
    
    suspend fun createProfile(profile: UserProfile) = profileDao.insertProfile(profile)
    
    suspend fun updateProfile(profile: UserProfile) = profileDao.updateProfile(profile)

    suspend fun insertServer(server: HostedServer): Long = serverDao.insertServer(server)

    suspend fun updateServer(server: HostedServer) = serverDao.updateServer(server)

    suspend fun deleteServer(server: HostedServer) = serverDao.deleteServer(server)

    fun getServerByIdFlow(id: Int): Flow<HostedServer?> = serverDao.getServerByIdFlow(id)

    suspend fun getServerById(id: Int): HostedServer? = serverDao.getServerById(id)

    fun getLogsForServer(serverId: Int): Flow<List<ServerLog>> = logDao.getLogsByServerId(serverId)

    suspend fun insertLog(serverId: Int, level: String, message: String) {
        val nodeName = listOf("Node-US-East", "Node-EU-Central", "Node-AS-South").random()
        logDao.insertLog(ServerLog(serverId = serverId, level = level, message = message, distributedNode = nodeName))
    }

    suspend fun clearLogs(serverId: Int) = logDao.clearLogsByServerId(serverId)

    // Prepopulate 20 Redeem Codes if empty
    suspend fun seedCodesIfEmpty() {
        val existing = redeemDao.getAllCodes()
        if (existing.isEmpty()) {
            val list = listOf(
                RedeemCode("DXCVYIDBJKBFLLP67TT", "5.99$"),
                RedeemCode("AERO599_K8F2J9X3N7P", "5.99$"),
                RedeemCode("AERO599_B7V5M2C8X9Z", "5.99$"),
                RedeemCode("AERO599_H4S8W1Q6Y3T", "5.99$"),
                RedeemCode("AERO599_F2G9D5S7A1Z", "5.99$"),
                RedeemCode("AERO899_M6K3J9N2P8Q", "8.99$"),
                RedeemCode("AERO899_X5Z8C1V9B3N", "8.99$"),
                RedeemCode("AERO899_F7D1S5A3Q9W", "8.99$"),
                RedeemCode("AERO899_G3H8J1K5L2M", "8.99$"),
                RedeemCode("AERO899_P2O9I3U8Y7T", "8.99$"),
                RedeemCode("AERO2999_Z1X9C2V8B3", "29.99$"),
                RedeemCode("AERO2999_A3S8D1F7G9", "29.99$"),
                RedeemCode("AERO2999_Q2W9E3R8T7", "29.99$"),
                RedeemCode("AERO2999_P1O8I2U7Y3", "29.99$"),
                RedeemCode("AERO2999_K3J8H2G7F9", "29.99$"),
                RedeemCode("AEROFREE_7N2M8K4J9L", "FREE"),
                RedeemCode("AEROFREE_V9C3X8Z2M7", "FREE"),
                RedeemCode("AEROFREE_W8Q3Y7T2R9", "FREE"),
                RedeemCode("AEROFREE_H4G9F2D8S3", "FREE"),
                RedeemCode("AEROFREE_U9I3O8P7T6", "FREE")
            )
            redeemDao.insertCodes(list)
        }
    }

    suspend fun getRedeemCode(codeStr: String): RedeemCode? = redeemDao.getCode(codeStr)

    suspend fun redeemCode(codeStr: String, email: String): String? {
        val codeObj = redeemDao.getCode(codeStr) ?: return "Code not found"
        if (codeObj.isRedeemed) {
            return "This code has already been used"
        }
        val currentProf = currentProfile.firstOrNull() ?: return "Please register or log in first"
        
        // Mark code as redeemed
        redeemDao.updateCode(codeObj.copy(isRedeemed = true, redeemedByEmail = email))
        
        // Update user profile tier
        profileDao.updateProfile(currentProf.copy(activeTier = codeObj.tier))
        return null // Success
    }

    suspend fun getAllRedeemCodes(): List<RedeemCode> {
        return redeemDao.getAllCodes()
    }
}
