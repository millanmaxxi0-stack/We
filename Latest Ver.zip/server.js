const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const AdmZip = require('adm-zip');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// Configure file storage for real ZIP uploads
const upload = multer({
  dest: 'uploads/',
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB Max limit
});

// Create directories if they don't exist
if (!fs.existsSync('uploads')) fs.mkdirSync('uploads');
if (!fs.existsSync('sandboxes')) fs.mkdirSync('sandboxes');

// Mock Datastore (Persisted to JSON files for lightweight production use)
const DATA_FILE = path.join(__dirname, 'db_store.json');
let dataStore = {
  users: [],
  servers: [],
  logs: [],
  redeemCodes: [
    "AERO-FREE-500", "AERO-CYBER-99", "AERO-CLOUD-88", "AERO-DEV-2026", "AERO-HOST-777",
    "AERO-FAST-123", "AERO-PRO-999", "AERO-NODE-JS", "AERO-PY-FAST", "AERO-LIVE-001",
    "AERO-BETA-77", "AERO-GOLD-55", "AERO-SAFE-88", "AERO-GIFT-500", "AERO-GIGA-256",
    "AERO-TERA-1024", "AERO-FREE-VIP", "AERO-SUPER-99", "AERO-ADMIN-01", "AERO-ROOT-99"
  ]
};

// Load data if exists
if (fs.existsSync(DATA_FILE)) {
  try {
    dataStore = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (e) {
    console.error("Failed to read database store, starting fresh.", e);
  }
}

function saveData() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(dataStore, null, 2), 'utf8');
}

// REST Endpoints
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Authentication
app.post('/api/auth/register', (req, res) => {
  const { username, password, email } = req.body;
  if (!username || !password || !email) {
    return res.status(400).json({ error: "All fields are required" });
  }
  const exists = dataStore.users.find(u => u.username === username || u.email === email);
  if (exists) {
    return res.status(400).json({ error: "Username or Email already registered" });
  }
  const newUser = {
    id: Date.now(),
    username,
    password, // In real apps, hash this using bcrypt
    email,
    activeTier: "FREE",
    balance: 0.0,
    twoFactorEnabled: false
  };
  dataStore.users.push(newUser);
  saveData();
  res.status(201).json({ success: true, user: { id: newUser.id, username, email, activeTier: "FREE" } });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const user = dataStore.users.find(u => u.username === username && u.password === password);
  if (!user) {
    return res.status(401).json({ error: "Invalid credentials" });
  }
  res.json({ success: true, user: { id: user.id, username: user.username, email: user.email, activeTier: user.activeTier, balance: user.balance } });
});

// Redeem Coupon Code
app.post('/api/billing/redeem', (req, res) => {
  const { userId, code } = req.body;
  const userIndex = dataStore.users.findIndex(u => u.id === parseInt(userId));
  if (userIndex === -1) return res.status(404).json({ error: "User not found" });

  if (dataStore.redeemCodes.includes(code.trim().toUpperCase())) {
    // Grant $15 for redeeming valid codes
    dataStore.users[userIndex].balance += 15.0;
    dataStore.users[userIndex].activeTier = "8.99$"; // Upgrade to silver cyber plan automatically!
    saveData();
    return res.json({
      success: true,
      message: "Successfully upgraded container specs! $15.00 credited to account wallet.",
      balance: dataStore.users[userIndex].balance,
      tier: dataStore.users[userIndex].activeTier
    });
  }
  res.status(400).json({ error: "Invalid or expired Redeem Code." });
});

// Get Live User Servers
app.get('/api/servers', (req, res) => {
  const userId = req.query.userId;
  const servers = dataStore.servers.filter(s => s.userId == userId);
  res.json(servers);
});

// Create hosting server
app.post('/api/servers/create', (req, res) => {
  const { userId, name, type, tier } = req.body;
  if (!name || !type) return res.status(400).json({ error: "Missing name or type" });

  const specs = {
    storage: 700,
    ram: 1024,
    cpu: 500,
    disk: 1024
  };
  if (tier === "5.99$") {
    specs.storage = 4000; specs.ram = 3072; specs.cpu = 1500; specs.disk = 2560;
  } else if (tier === "8.99$") {
    specs.storage = 8000; specs.ram = 6144; specs.cpu = 3000; specs.disk = 6144;
  } else if (tier === "29.99$") {
    specs.storage = 100000; specs.ram = 65536; specs.cpu = 16000; specs.disk = 32768;
  }

  const serverId = Date.now();
  const domain = `${name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${serverId.toString().slice(-4)}.aerohost.app`;
  
  const newServer = {
    id: serverId,
    userId: parseInt(userId),
    name,
    type,
    status: "RUNNING",
    domain,
    specs,
    env: { "PORT": "3000", "NODE_ENV": "production" },
    database: { type: null, connectionUri: null, status: 'NOT_PROVISIONED' },
    history: [
      { id: Date.now(), type: "PROVISION", timestamp: new Date().toLocaleTimeString(), message: "Isolated container created successfully." }
    ],
    files: [
      { name: "package.json", content: `{\n  "name": "${name.toLowerCase().replace(/\s+/g, '-')}",\n  "version": "1.0.0",\n  "main": "server.js",\n  "dependencies": {\n    "express": "^4.18.2"\n  }\n}` },
      { name: "server.js", content: `const express = require('express');\nconst app = express();\nconst port = process.env.PORT || 3000;\n\napp.get('/', (req, res) => {\n  res.send('<h1>Active Sandbox Server: ${name}</h1><p>Online on AeroHost Production</p>');\n});\n\napp.listen(port, () => {\n  console.log('Server loaded on port ' + port);\n});` },
      { name: "index.html", content: `<!DOCTYPE html>\n<html>\n<head><title>${name}</title></head>\n<body style="font-family:sans-serif; text-align:center; padding:10%;">\n<h1>Server online!</h1>\n</body>\n</html>` }
    ],
    logs: [
      `[SYSTEM] Dynamic virtual container generated.`,
      `[SYSTEM] Isolated sandbox namespace instantiated.`,
      `[SYSTEM] Server active and listening at http://${domain}`
    ],
    metrics: { cpu: 12, ram: 145, disk: 18 }
  };

  dataStore.servers.push(newServer);
  saveData();
  res.status(201).json(newServer);
});

// Upload ZIP deployer
app.post('/api/servers/:id/deploy', upload.single('zipfile'), (req, res) => {
  const serverId = parseInt(req.params.id);
  const file = req.file;
  if (!file) return res.status(400).json({ error: "No ZIP file uploaded" });

  const targetServerIndex = dataStore.servers.findIndex(s => s.id === serverId);
  if (targetServerIndex === -1) return res.status(404).json({ error: "Server not found" });

  try {
    const zip = new AdmZip(file.path);
    const zipEntries = zip.getEntries();
    const extractedFiles = [];

    zipEntries.forEach(entry => {
      if (!entry.isDirectory) {
        const parts = entry.entryName.split('/');
        const filename = parts[parts.length - 1];
        if (filename.match(/\.(js|py|json|html|css|txt|md)$/i)) {
          extractedFiles.push({
            name: filename,
            content: entry.getData().toString('utf8')
          });
        }
      }
    });

    if (extractedFiles.length === 0) {
      fs.unlinkSync(file.path);
      return res.status(400).json({ error: "No valid hosting files (.js, .py, .json, .html, etc.) found in ZIP" });
    }

    // Replace server files with extracted ones
    dataStore.servers[targetServerIndex].files = extractedFiles;
    dataStore.servers[targetServerIndex].status = "RUNNING";
    
    const timestamp = new Date().toISOString();
    dataStore.servers[targetServerIndex].logs.push(
      `[ZIP-EXTRACTOR] ${timestamp} Extracted ${extractedFiles.length} file(s) from ZIP file successfully.`,
      `[BUILD] Installing dynamic node modules and parsing configurations...`,
      `[RUNTIME] Re-starting main process server entrypoint...`,
      `[HEALTH-CHECK] Container status verified: Online.`
    );

    saveData();
    fs.unlinkSync(file.path); // Clean temp file

    // Emit live reload signal over socket
    io.to(serverId.toString()).emit('server_reloaded', dataStore.servers[targetServerIndex]);

    res.json({ success: true, message: "Extracted and hosted successfully!", files: extractedFiles });
  } catch (error) {
    if (fs.existsSync(file.path)) fs.unlinkSync(file.path);
    res.status(500).json({ error: "Failed to extract ZIP archive: " + error.message });
  }
});

// Edit or save single file content
app.post('/api/servers/:id/files/save', (req, res) => {
  const serverId = parseInt(req.params.id);
  const { name, content } = req.body;
  if (!name) return res.status(400).json({ error: "File name is required" });

  const targetServerIndex = dataStore.servers.findIndex(s => s.id === serverId);
  if (targetServerIndex === -1) return res.status(404).json({ error: "Server not found" });

  const fileIndex = dataStore.servers[targetServerIndex].files.findIndex(f => f.name === name);
  if (fileIndex !== -1) {
    dataStore.servers[targetServerIndex].files[fileIndex].content = content;
  } else {
    dataStore.servers[targetServerIndex].files.push({ name, content });
  }

  // Update logs and history
  dataStore.servers[targetServerIndex].logs.push(`[BUILD] File '${name}' updated/saved. Re-building container...`);
  dataStore.servers[targetServerIndex].history.push({
    id: Date.now(),
    type: "FILE_EDIT",
    timestamp: new Date().toLocaleTimeString(),
    message: `Updated code file: ${name}`
  });

  saveData();
  io.to(serverId.toString()).emit('server_reloaded', dataStore.servers[targetServerIndex]);
  res.json({ success: true, message: "File saved and container redeployed!" });
});

// Add new file
app.post('/api/servers/:id/files/add', (req, res) => {
  const serverId = parseInt(req.params.id);
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: "File name is required" });

  const targetServerIndex = dataStore.servers.findIndex(s => s.id === serverId);
  if (targetServerIndex === -1) return res.status(404).json({ error: "Server not found" });

  const exists = dataStore.servers[targetServerIndex].files.some(f => f.name === name);
  if (exists) return res.status(400).json({ error: "File already exists" });

  dataStore.servers[targetServerIndex].files.push({ name, content: `// File: ${name}\n` });
  dataStore.servers[targetServerIndex].logs.push(`[SYSTEM] Added new file: ${name}`);
  
  saveData();
  io.to(serverId.toString()).emit('server_reloaded', dataStore.servers[targetServerIndex]);
  res.json({ success: true, message: "File added successfully!" });
});

// Delete file
app.post('/api/servers/:id/files/delete', (req, res) => {
  const serverId = parseInt(req.params.id);
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: "File name is required" });

  const targetServerIndex = dataStore.servers.findIndex(s => s.id === serverId);
  if (targetServerIndex === -1) return res.status(404).json({ error: "Server not found" });

  const files = dataStore.servers[targetServerIndex].files;
  const filtered = files.filter(f => f.name !== name);
  if (files.length === filtered.length) return res.status(404).json({ error: "File not found" });

  dataStore.servers[targetServerIndex].files = filtered;
  dataStore.servers[targetServerIndex].logs.push(`[SYSTEM] Deleted file: ${name}`);

  saveData();
  io.to(serverId.toString()).emit('server_reloaded', dataStore.servers[targetServerIndex]);
  res.json({ success: true, message: "File deleted successfully!" });
});

// Save Environment Variables
app.post('/api/servers/:id/env', (req, res) => {
  const serverId = parseInt(req.params.id);
  const { env } = req.body; // Key-value object
  if (!env) return res.status(400).json({ error: "Env object is required" });

  const targetServerIndex = dataStore.servers.findIndex(s => s.id === serverId);
  if (targetServerIndex === -1) return res.status(404).json({ error: "Server not found" });

  dataStore.servers[targetServerIndex].env = env;
  dataStore.servers[targetServerIndex].logs.push(`[CONFIG] Applied ${Object.keys(env).length} environment variables. Restarting services...`);
  
  saveData();
  io.to(serverId.toString()).emit('server_reloaded', dataStore.servers[targetServerIndex]);
  res.json({ success: true, message: "Environment variables saved and container restarted!" });
});

// Provision Database (MongoDB, PostgreSQL, Redis)
app.post('/api/servers/:id/database', (req, res) => {
  const serverId = parseInt(req.params.id);
  const { type } = req.body; // 'postgresql', 'mongodb', 'redis'
  if (!type) return res.status(400).json({ error: "Database type is required" });

  const targetServerIndex = dataStore.servers.findIndex(s => s.id === serverId);
  if (targetServerIndex === -1) return res.status(404).json({ error: "Server not found" });

  const dbPassword = Math.random().toString(36).slice(-8);
  const host = `${type}.aerohost.app`;
  let connectionUri = "";

  if (type === 'postgresql') {
    connectionUri = `postgresql://admin:${dbPassword}@${host}:5432/sandbox_db`;
  } else if (type === 'mongodb') {
    connectionUri = `mongodb://admin:${dbPassword}@${host}:27017/sandbox_db?authSource=admin`;
  } else {
    connectionUri = `redis://default:${dbPassword}@${host}:6379`;
  }

  dataStore.servers[targetServerIndex].database = {
    type,
    connectionUri,
    status: 'ACTIVE'
  };

  dataStore.servers[targetServerIndex].logs.push(`[DATABASE] Provisioned new isolated ${type.toUpperCase()} database container.`);
  dataStore.servers[targetServerIndex].logs.push(`[DATABASE] URI: ${connectionUri}`);

  saveData();
  io.to(serverId.toString()).emit('server_reloaded', dataStore.servers[targetServerIndex]);
  res.json({ success: true, message: `${type.toUpperCase()} database provisioned and connected!`, database: dataStore.servers[targetServerIndex].database });
});

// Power control: Start, Stop, Restart
app.post('/api/servers/:id/power', (req, res) => {
  const serverId = parseInt(req.params.id);
  const { action } = req.body; // 'START', 'STOP', 'RESTART'
  if (!action) return res.status(400).json({ error: "Action is required" });

  const targetServerIndex = dataStore.servers.findIndex(s => s.id === serverId);
  if (targetServerIndex === -1) return res.status(404).json({ error: "Server not found" });

  if (action === 'START') {
    dataStore.servers[targetServerIndex].status = "RUNNING";
    dataStore.servers[targetServerIndex].logs.push(`[POWER] Initiating server launch sequence...`, `[POWER] Online and listening on port 3000.`);
  } else if (action === 'STOP') {
    dataStore.servers[targetServerIndex].status = "STOPPED";
    dataStore.servers[targetServerIndex].logs.push(`[POWER] Shutting down container gracefully...`, `[POWER] Service is offline.`);
  } else if (action === 'RESTART') {
    dataStore.servers[targetServerIndex].status = "RUNNING";
    dataStore.servers[targetServerIndex].logs.push(`[POWER] Rebooting container sandbox...`, `[POWER] Online and healthy.`);
  }

  saveData();
  io.to(serverId.toString()).emit('server_reloaded', dataStore.servers[targetServerIndex]);
  res.json({ success: true, status: dataStore.servers[targetServerIndex].status });
});

// Update Subdomain or Name Settings
app.post('/api/servers/:id/settings', (req, res) => {
  const serverId = parseInt(req.params.id);
  const { name, subdomain } = req.body;

  const targetServerIndex = dataStore.servers.findIndex(s => s.id === serverId);
  if (targetServerIndex === -1) return res.status(404).json({ error: "Server not found" });

  if (name) dataStore.servers[targetServerIndex].name = name;
  if (subdomain) {
    const formattedSub = subdomain.toLowerCase().replace(/[^a-z0-9-]/g, '');
    dataStore.servers[targetServerIndex].domain = `${formattedSub}.aerohost.app`;
  }

  dataStore.servers[targetServerIndex].logs.push(`[SYSTEM] Server network configurations updated. Subdomain: ${dataStore.servers[targetServerIndex].domain}`);
  
  saveData();
  io.to(serverId.toString()).emit('server_reloaded', dataStore.servers[targetServerIndex]);
  res.json({ success: true, message: "Settings updated successfully!", server: dataStore.servers[targetServerIndex] });
});

// WebSockets for Real-time Streaming Metrics & Terminal Updates
io.on('connection', (socket) => {
  let activeServerId = null;
  let metricsInterval = null;

  socket.on('join_server', (serverId) => {
    activeServerId = serverId;
    socket.join(serverId.toString());
    
    // Periodically send random dynamic logs & metrics to simulate real running tasks
    metricsInterval = setInterval(() => {
      const server = dataStore.servers.find(s => s.id === parseInt(serverId));
      if (server && server.status === "RUNNING") {
        const cpuInc = Math.floor(Math.random() * 8) + 2;
        const ramInc = Math.floor(Math.random() * 15) + 120;
        const diskInc = Math.floor(Math.random() * 2) + 15;
        
        const metrics = { cpu: cpuInc, ram: ramInc, disk: diskInc };
        io.to(serverId.toString()).emit('metrics_update', metrics);
      }
    }, 2500);
  });

  socket.on('disconnect', () => {
    if (metricsInterval) clearInterval(metricsInterval);
  });
});

// Start the unified backend server
server.listen(PORT, () => {
  console.log(`===========================================================`);
  console.log(` AeroHost Hosting Server Running on port ${PORT}`);
  console.log(` Web Dashboard available at: http://localhost:${PORT}`);
  console.log(`===========================================================`);
});
